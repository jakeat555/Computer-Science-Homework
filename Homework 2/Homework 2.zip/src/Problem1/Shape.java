package Problem1;

public class Shape{
    private double side;
    public double getArea(){
        return -1;
    }

    public void setSide(double s){
        System.out.println("This is the shape setSide()");
        side = s;
    }
}
