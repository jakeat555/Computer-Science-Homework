
public class Employee extends Person {
    private String office;
    private double salary;
    private MyDate hireDate;

    Employee(){
        office = "MAIN 001";
        salary = 120000;
        hireDate = new MyDate(29,2,1996);
    }

    Employee(String o, double s, MyDate d){
        office=o;
        salary=s;
        hireDate=d;
    }

    public String toString() {
        return getName() + " is of the Employee class";
    }

    public String getOffice() {
        return office;
    }

    public double getSalary() {
        return salary;
    }

    public MyDate getHireDate() {
        return hireDate;
    }

    public void setHireDate(MyDate hireDate) {
        this.hireDate = hireDate;
    }

    public void setOffice(String office) {
        this.office = office;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}
