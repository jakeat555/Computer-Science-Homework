public class Faculty extends Employee{
    private String officeHours;
    private String rank;

    Faculty(){
        officeHours = "Never";
        rank="rank unknown";
    }

    Faculty(String o, String r){
        officeHours = o;
        rank=r;
    }

    public String toString(){
        return getName()+ " is of the Faculty class";
    }

    public String getOfficeHours() {
        return officeHours;
    }

    public String getRank() {
        return rank;
    }

    public void setOfficeHours(String officeHours) {
        this.officeHours = officeHours;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }
}
