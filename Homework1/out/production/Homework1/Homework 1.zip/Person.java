public class Person {
    private String name;
    private String email;
    private String address;
    private String phoneNum;

    Person(){
        name = "Jane Doe";
        email = "example@example.net";
        address = "123 Main street";
        phoneNum = "555-555-1738";
    }

    Person(String n, String e, String a, String p){
        name = n;
        email = e;
        address= a;
        phoneNum = p;
    }

    public String toString(){
        return name+ " is of the Person class";
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNum() {
        return phoneNum;
    }
}