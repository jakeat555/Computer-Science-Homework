public class Staff extends Employee {
    private String title;

    Staff(){
        title = "title unknown";
    }

    Staff(String t){
        title=t;
    }

    public String toString(){
        return getName()+ " is of the Staff class";
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
