class TestPerson{
    public static void main(String[] args) {
        Person p = new Person();
        Student q = new Student();
        Employee r = new Employee();
        Faculty s = new Faculty();
        Staff t = new Staff();
        System.out.println("p:" + p.toString() + " and lives at " + p.getAddress());
        System.out.println("q:" + q.toString() + " and has status : " + q.getStatus());
        System.out.println("r:" + r.toString() + " and has salary : $" + r.getSalary());
        System.out.println("s:" + s.toString() + " and has office hours :" + s.getOfficeHours());
        System.out.println("t:" + t.toString() + " and has title: " + t.getTitle());

    }
}